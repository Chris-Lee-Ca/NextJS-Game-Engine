import { AppDispatch, AppStore } from "./levelSlice";
import { AllLevelInfo, LevelInfo } from "./types";
import { GameObjectFactory } from "../../../components/GameObjectFactory";
import PluginHandler from "../PluginHandler";
export interface LevelHandlerConfig {
    store: AppStore;
    dispatch: AppDispatch;
    gameObjectFactory: GameObjectFactory;
    currentLevel: string;
    allLevelInfo: AllLevelInfo;
    onLevelChanged?: (newLevelInfo: LevelInfo, previousLevelInfo: LevelInfo | undefined) => void;
}
export declare class LevelHandler implements PluginHandler {
    pluginId: string;
    private store;
    private dispatch;
    private objectPool;
    private gameObjectFactory;
    private previousLevelInfo;
    private onLevelChanged?;
    constructor({ store, dispatch, gameObjectFactory, currentLevel, allLevelInfo, onLevelChanged, }: LevelHandlerConfig);
    init(): void;
    loadLevel(): void;
    deinit(): void;
    update(_deltaTime: number): void;
    private createMapBoundry;
    private createGameObject;
    private createInvisibleWall;
}
