import { setAllLevelInfo, setCurrentLevel } from "./levelSlice";
import ObjectPool from "../../../core/ObjectPool";
import InvisibleWall from "../../../components/InvisibleWall";
import { LEVEL_PLUGIN_ID } from ".";
import { setObjectIdPool } from "../../../redux/features/coreSlice";
export class LevelHandler {
    constructor({ store, dispatch, gameObjectFactory, currentLevel, allLevelInfo, onLevelChanged, }) {
        this.pluginId = LEVEL_PLUGIN_ID;
        this.store = store;
        this.dispatch = dispatch;
        this.gameObjectFactory = gameObjectFactory;
        this.objectPool = ObjectPool;
        this.onLevelChanged = onLevelChanged;
        this.dispatch(setCurrentLevel(currentLevel));
        this.dispatch(setAllLevelInfo(allLevelInfo));
    }
    init() {
        this.loadLevel();
    }
    loadLevel() {
        var _a;
        if (typeof this.store === "undefined" || typeof this.dispatch === "undefined") {
            throw new Error('Please call "init" method for LevelHandler');
        }
        //reset object pool
        this.objectPool.clear();
        const state = this.store.getState();
        const levelState = state[LEVEL_PLUGIN_ID];
        const currentLevelInfo = levelState.allLevelInfo[levelState.currentLevel];
        this.createMapBoundry(currentLevelInfo);
        const currentLevelPlacements = currentLevelInfo.placements;
        const newObjectIdPool = currentLevelPlacements.map((placement) => placement.id);
        this.dispatch(setObjectIdPool(newObjectIdPool));
        currentLevelPlacements.forEach((placement) => {
            this.createGameObject(placement);
        });
        const previousLevelInfo = this.previousLevelInfo;
        this.previousLevelInfo = currentLevelInfo;
        (_a = this.onLevelChanged) === null || _a === void 0 ? void 0 : _a.call(this, currentLevelInfo, previousLevelInfo);
    }
    deinit() { }
    update(_deltaTime) {
        const levelState = this.store.getState()[LEVEL_PLUGIN_ID];
        const currentLevelInfo = levelState.allLevelInfo[levelState.currentLevel];
        const currentLevelPlacements = currentLevelInfo.placements;
        // Add objects that are in placements but not in the objectPool
        currentLevelPlacements.forEach((placement) => {
            if (!this.objectPool.has(placement.id)) {
                this.createGameObject(placement);
            }
        });
        // Update Object ID Pool
        const { objectIdPool } = this.store.getState().core;
        const newObjectIdPool = currentLevelPlacements.map((placement) => placement.id);
        const poolChanged = objectIdPool.length !== newObjectIdPool.length ||
            objectIdPool.some((id, i) => id !== newObjectIdPool[i]);
        if (poolChanged) {
            this.dispatch(setObjectIdPool(newObjectIdPool));
        }
        // Remove objects that are in objectPool but not in placements
        // except it is a invisibleWall (map boundary)
        const placementIds = new Set(currentLevelPlacements.map((p) => p.id));
        this.objectPool.forEach((_, objectId) => {
            if (!placementIds.has(objectId) && !objectId.startsWith("Other-invisible-wall")) {
                this.objectPool.delete(objectId);
            }
        });
        // Re-create map boundry if the map size change
        const previousLevelInfo = this.previousLevelInfo;
        if (previousLevelInfo.tilesHeight !== currentLevelInfo.tilesHeight ||
            previousLevelInfo.tilesWidth !== currentLevelInfo.tilesWidth) {
            this.objectPool.forEach((_, objectId) => {
                if (objectId.startsWith("Other-invisible-wall")) {
                    this.objectPool.delete(objectId);
                }
            });
            this.createMapBoundry(currentLevelInfo);
        }
        this.previousLevelInfo = currentLevelInfo;
    }
    createMapBoundry(currentLevelInfo) {
        for (let x = 0; x < currentLevelInfo.tilesWidth; x++) {
            this.createInvisibleWall({ x, y: -1 });
            this.createInvisibleWall({ x, y: currentLevelInfo.tilesHeight });
        }
        for (let y = 0; y < currentLevelInfo.tilesHeight; y++) {
            this.createInvisibleWall({ x: -1, y });
            this.createInvisibleWall({ x: currentLevelInfo.tilesWidth, y });
        }
    }
    createGameObject(placement) {
        const params = {
            placement,
            reduxStore: this.store,
        };
        const gameObject = this.gameObjectFactory.createObject(params);
        this.objectPool.set(placement.id, gameObject);
    }
    createInvisibleWall(coord) {
        const invisibleWallPlacement = {
            id: `Other-invisible-wall-${coord.x}-${coord.y}`,
            coord: coord,
            type: "Other",
            itemName: "invisible wall",
        };
        const invisibleWallObject = new InvisibleWall({ placement: invisibleWallPlacement });
        this.objectPool.set(invisibleWallPlacement.id, invisibleWallObject);
    }
}
