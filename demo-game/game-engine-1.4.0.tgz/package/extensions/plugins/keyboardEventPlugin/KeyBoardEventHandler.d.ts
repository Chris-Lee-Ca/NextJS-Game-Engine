import { AppDispatch } from "./keyboardEventSlice";
import PluginHandler from "../PluginHandler";
export interface KeyboardEventHandlerConfig {
    dispatch: AppDispatch;
}
export declare class KeyboardEventHandler implements PluginHandler {
    pluginId: string;
    private dispatch;
    private heldKeys;
    constructor({ dispatch }: KeyboardEventHandlerConfig);
    init(): void;
    deinit(): void;
    update(deltaTime: number): void;
    handleKeyUp(event: KeyboardEvent): void;
    handleKeyDown(event: KeyboardEvent): void;
    private handleWindowFocus;
}
