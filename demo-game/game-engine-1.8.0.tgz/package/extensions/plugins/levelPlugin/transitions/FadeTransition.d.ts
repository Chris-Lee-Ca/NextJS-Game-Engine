import { LevelTransitionComponent } from "../types";
export interface FadeTransitionOptions {
    color?: string;
    revealDurationMs?: number;
    fallbackMs?: number;
}
/**
 * Goes fully opaque the instant a level change starts, stays that way for as long as the new
 * level actually takes to load, and only fades back out once LevelHandler reports the load is
 * done.
 */
export declare const FadeTransition: (options?: FadeTransitionOptions) => LevelTransitionComponent;
