import { AppDispatch, AppStore } from "./levelSlice";
import { AllLevelInfo, LevelInfo, LevelTransitionComponent } from "./types";
import { GameObjectFactory } from "../../../components/GameObjectFactory";
import PluginHandler from "../PluginHandler";
export interface LevelHandlerConfig {
    store: AppStore;
    dispatch: AppDispatch;
    gameObjectFactory: GameObjectFactory;
    currentLevel: string;
    allLevelInfo: AllLevelInfo;
    onLevelChanged?: (newLevelInfo: LevelInfo, previousLevelInfo: LevelInfo | undefined) => void;
    /** Pass a transition (e.g. `FadeTransition()`) to visualize level loads, or omit for none. */
    transition?: LevelTransitionComponent;
}
export declare class LevelHandler implements PluginHandler {
    pluginId: string;
    readonly transition?: LevelTransitionComponent;
    private store;
    private dispatch;
    private objectPool;
    private gameObjectFactory;
    private previousLevelInfo;
    private onLevelChanged?;
    constructor({ store, dispatch, gameObjectFactory, currentLevel, allLevelInfo, onLevelChanged, transition, }: LevelHandlerConfig);
    init(): void;
    loadLevel(): void;
    deinit(): void;
    update(_deltaTime: number): void;
    private createMapBoundry;
    private createGameObject;
    private createInvisibleWall;
}
