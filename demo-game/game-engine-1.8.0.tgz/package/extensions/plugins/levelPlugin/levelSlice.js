import { configureStore, createSlice } from "@reduxjs/toolkit";
import { LEVEL_PLUGIN_ID } from "./constants";
import { coreReducer } from "../../../redux/features/coreSlice";
const initialState = {
    currentLevel: "",
    allLevelInfo: {},
    isTransitioning: false,
};
export const levelSlice = createSlice({
    name: "level",
    initialState,
    reducers: {
        setCurrentLevel: (state, action) => {
            // Guarded so the initial bootstrap dispatch (currentLevel: "" -> first level) doesn't
            // flash a transition — only an actual change away from a real level counts.
            if (state.currentLevel && state.currentLevel !== action.payload) {
                state.isTransitioning = true;
            }
            state.currentLevel = action.payload;
        },
        endLevelTransition: (state) => {
            state.isTransitioning = false;
        },
        setAllLevelInfo: (state, action) => {
            state.allLevelInfo = action.payload;
        },
        setLevelInfoByKey: (state, action) => {
            state.allLevelInfo[action.payload.key] = action.payload.levelInfo;
        },
    },
});
export const selectCurrentLevelInfo = (state) => {
    const currentLevel = state[LEVEL_PLUGIN_ID].currentLevel;
    return state.level.allLevelInfo[currentLevel];
};
export const updateCurrentLevelInfo = (levelInfo) => (dispatch) => {
    dispatch(setLevelInfoByKey({ key: levelInfo.levelTitle, levelInfo: levelInfo }));
    dispatch(setCurrentLevel(levelInfo.levelTitle));
};
export const { setCurrentLevel, endLevelTransition, setAllLevelInfo, setLevelInfoByKey } = levelSlice.actions;
export const levelReducer = levelSlice.reducer;
const makeStore = () => {
    return configureStore({
        reducer: {
            core: coreReducer,
            [LEVEL_PLUGIN_ID]: levelReducer,
        },
    });
};
