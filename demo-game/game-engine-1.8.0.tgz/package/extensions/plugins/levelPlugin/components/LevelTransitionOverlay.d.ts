import { LevelTransitionComponent } from "../types";
export interface LevelTransitionOverlayProps {
    transition?: LevelTransitionComponent;
}
export declare const LevelTransitionOverlay: ({ transition: Transition }: LevelTransitionOverlayProps) => import("react").JSX.Element | null;
