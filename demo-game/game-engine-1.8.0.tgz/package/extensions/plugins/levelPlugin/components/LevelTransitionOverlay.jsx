"use client";
import { useSelector } from "react-redux";
import { LEVEL_PLUGIN_ID } from "../constants";
export const LevelTransitionOverlay = ({ transition: Transition }) => {
    const isTransitioning = useSelector((state) => state[LEVEL_PLUGIN_ID].isTransitioning);
    if (!Transition)
        return null;
    return <Transition isTransitioning={isTransitioning}/>;
};
