import type { PayloadAction } from "@reduxjs/toolkit";
import { AllLevelInfo, LevelInfo } from "./types";
export interface LevelStateInterface {
    currentLevel: string;
    allLevelInfo: AllLevelInfo;
    isTransitioning: boolean;
}
export declare const levelSlice: import("@reduxjs/toolkit").Slice<LevelStateInterface, {
    setCurrentLevel: (state: import("immer").WritableDraft<LevelStateInterface>, action: PayloadAction<string>) => void;
    endLevelTransition: (state: import("immer").WritableDraft<LevelStateInterface>) => void;
    setAllLevelInfo: (state: import("immer").WritableDraft<LevelStateInterface>, action: PayloadAction<AllLevelInfo>) => void;
    setLevelInfoByKey: (state: import("immer").WritableDraft<LevelStateInterface>, action: PayloadAction<{
        key: string;
        levelInfo: LevelInfo;
    }>) => void;
}, "level", "level", import("@reduxjs/toolkit").SliceSelectors<LevelStateInterface>>;
export declare const selectCurrentLevelInfo: (state: RootState) => LevelInfo;
export declare const updateCurrentLevelInfo: (levelInfo: LevelInfo) => (dispatch: AppDispatch) => void;
export declare const setCurrentLevel: import("@reduxjs/toolkit").ActionCreatorWithPayload<string, "level/setCurrentLevel">, endLevelTransition: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"level/endLevelTransition">, setAllLevelInfo: import("@reduxjs/toolkit").ActionCreatorWithPayload<AllLevelInfo, "level/setAllLevelInfo">, setLevelInfoByKey: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    key: string;
    levelInfo: LevelInfo;
}, "level/setLevelInfoByKey">;
export declare const levelReducer: import("redux").Reducer<LevelStateInterface>;
declare const makeStore: () => import("@reduxjs/toolkit").EnhancedStore<{
    core: import("../../../redux/features/coreSlice").CoreStateInterface;
    level: LevelStateInterface;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<{
        core: import("../../../redux/features/coreSlice").CoreStateInterface;
        level: LevelStateInterface;
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
export type AppStore = ReturnType<typeof makeStore>;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];
export {};
