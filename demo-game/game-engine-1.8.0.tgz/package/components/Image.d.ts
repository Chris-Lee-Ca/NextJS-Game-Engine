import { CSSProperties } from "react";
interface ImageProps {
    src: string;
    alt: string;
    style?: CSSProperties;
}
declare const Image: (props: ImageProps) => import("react").JSX.Element;
export default Image;
