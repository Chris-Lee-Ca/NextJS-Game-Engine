"use client";
import { styled } from "@mui/material";
const Img = styled("img")({
    width: `100%`,
    height: `100%`,
});
const Image = (props) => {
    const { src, alt, style } = props;
    return <Img src={src} alt={alt} style={Object.assign({}, style)}/>;
};
export default Image;
