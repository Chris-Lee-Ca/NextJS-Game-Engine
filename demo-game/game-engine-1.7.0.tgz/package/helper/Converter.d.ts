import { Coordinate, Vector2 } from "../types/general";
declare class Converter {
    static coordToVector(coord: Coordinate): Vector2;
    static vectorToCoord(vector: Vector2): Coordinate;
}
export default Converter;
