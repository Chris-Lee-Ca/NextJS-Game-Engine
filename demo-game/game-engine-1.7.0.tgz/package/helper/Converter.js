import GridHelper from "./GridHelper";
class Converter {
    static coordToVector(coord) {
        const gridPixelSize = GridHelper.getGridSizeInPixel();
        return {
            x: coord.x * gridPixelSize,
            y: coord.y * gridPixelSize,
        };
    }
    static vectorToCoord(vector) {
        const gridPixelSize = GridHelper.getGridSizeInPixel();
        return {
            x: Math.floor(vector.x / gridPixelSize),
            y: Math.floor(vector.y / gridPixelSize),
        };
    }
}
export default Converter;
