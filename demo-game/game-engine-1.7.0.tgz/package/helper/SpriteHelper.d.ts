import { Vector2, SpriteSheetInfo, Offset } from "../types/general";
declare class SpriteHelper {
    /**
     * Converts sprite grid position to image position on the sprite sheet.
     * @param {number} row - The row in the sprite sheet grid.
     * @param {number} col - The column in the sprite sheet grid.
     * @param {SpriteSheetInfo} spriteSheetInfo - Information about the sprite sheet.
     * @param {Object} imageOffset - The x and y offsets for the image.
     * @returns {Vector2} - The x and y position on the image.
     */
    static spritePositionToImagePosition(row: number, col: number, spriteSheetInfo: SpriteSheetInfo, imageOffset: Offset): Vector2;
    /**
     * Calculates the scale factor for the sprite sheet based on the grid size and sprite sheet dimensions.
     * @param {SpriteSheetInfo} spriteSheetInfo - Information about the sprite sheet.
     * @returns {number} - The scale factor for the sprite sheet.
     * @throws {Error} - If the sprite sheet info width and height are not equal.
     */
    static getSpriteSheetScaleFactor(spriteSheetInfo: SpriteSheetInfo): number;
}
export default SpriteHelper;
