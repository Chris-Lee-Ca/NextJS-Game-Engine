import { Pixel } from "../types/general";
declare class GridHelper {
    /**
     * Retrieves the CSS custom property value for --scale-factor.
     * @returns {number} - The value of the CSS variable --scale-factor.
     */
    static getScaleFactor(): number;
    /**
     * Calculates the actual pixel size of the grid after applying the scale factor.
     * @returns {number} - The pixel size of the grid.
     */
    static getGridSizeInPixel(): Pixel;
}
export default GridHelper;
