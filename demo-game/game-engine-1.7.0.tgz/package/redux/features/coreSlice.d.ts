import { PayloadAction } from "@reduxjs/toolkit";
export interface CoreStateInterface {
    time: number;
    objectIdPool: string[];
}
export declare const coreSlice: import("@reduxjs/toolkit").Slice<CoreStateInterface, {
    updateTime: (state: import("immer").WritableDraft<CoreStateInterface>) => void;
    setObjectIdPool: (state: import("immer").WritableDraft<CoreStateInterface>, action: PayloadAction<string[]>) => void;
}, "core", "core", import("@reduxjs/toolkit").SliceSelectors<CoreStateInterface>>;
export declare const updateTime: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"core/updateTime">, setObjectIdPool: import("@reduxjs/toolkit").ActionCreatorWithPayload<string[], "core/setObjectIdPool">;
export declare const coreReducer: import("redux").Reducer<CoreStateInterface>;
