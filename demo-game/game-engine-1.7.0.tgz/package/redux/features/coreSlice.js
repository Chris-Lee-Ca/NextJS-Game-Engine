import { createSlice } from "@reduxjs/toolkit";
const initialState = {
    time: Date.now(),
    objectIdPool: [],
};
export const coreSlice = createSlice({
    name: "core",
    initialState,
    reducers: {
        updateTime: (state) => {
            state.time = Date.now();
        },
        setObjectIdPool: (state, action) => {
            state.objectIdPool = action.payload;
        },
    },
});
export const { updateTime, setObjectIdPool } = coreSlice.actions;
export const coreReducer = coreSlice.reducer;
