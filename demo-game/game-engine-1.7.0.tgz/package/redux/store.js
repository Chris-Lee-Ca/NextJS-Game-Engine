import { configureStore } from "@reduxjs/toolkit";
import { coreReducer } from "./features/coreSlice";
export const gameEngineReducer = {
    core: coreReducer,
};
export const makeGameEngineStore = () => {
    return configureStore({
        reducer: gameEngineReducer,
    });
};
