export declare const gameEngineReducer: {
    core: import("redux").Reducer<import("./features/coreSlice").CoreStateInterface>;
};
export declare const makeGameEngineStore: () => import("@reduxjs/toolkit").EnhancedStore<{
    core: import("./features/coreSlice").CoreStateInterface;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<{
        core: import("./features/coreSlice").CoreStateInterface;
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
export type AppStore = ReturnType<typeof makeGameEngineStore>;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];
