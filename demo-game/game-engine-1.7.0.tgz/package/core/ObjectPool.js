const ObjectPool = new Map();
export default ObjectPool;
