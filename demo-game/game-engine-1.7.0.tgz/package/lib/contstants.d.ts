export declare const GRID: {
    SIZE: number;
    DEFAULT_SCALE_FACTOR: number;
};
