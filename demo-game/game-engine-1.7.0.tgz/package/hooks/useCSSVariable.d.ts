export declare const useCSSVariable: (variableName: string) => number;
