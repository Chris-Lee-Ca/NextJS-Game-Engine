import ModuleHandler from "../ModuleHandler";
import { AppDispatch, AppStore } from "./mainCharacterActionSlice";
import { ActionKeyMapping } from "./types";
export interface ActionControlHandlerConfig {
    store: AppStore;
    dispatch: AppDispatch;
    actionKeyMapping: ActionKeyMapping;
}
export declare class ActionControlHandler implements ModuleHandler {
    pluginId: string;
    moduleId: string;
    private store;
    private dispatch;
    private invertedKeyMapping;
    constructor({ store, dispatch, actionKeyMapping }: ActionControlHandlerConfig);
    private getInvertedActionKeyMapping;
    init(): void;
    deinit(): void;
    update(_deltaTime: number): void;
    private getHeldActionKeys;
}
export default ActionControlHandler;
