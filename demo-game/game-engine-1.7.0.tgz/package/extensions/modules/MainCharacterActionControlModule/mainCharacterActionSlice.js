import { configureStore, createSlice } from "@reduxjs/toolkit";
import { KEYBOARD_EVENT_PLUGIN_ID, keyboardEventReducer } from "../../plugins/keyboardEventPlugin";
import { MAIN_CHARACTER_ACTION_CONTROL_MODULE_ID } from "./constants";
const initialState = {
    disabled: false,
    heldActionKeys: [],
};
export const mainCharacterActionSlice = createSlice({
    name: "mainCharacter",
    initialState,
    reducers: {
        setIsDisabledMainCharacterActionControl: (state, action) => {
            state.disabled = action.payload;
        },
        setHeldActionKeys: (state, action) => {
            state.heldActionKeys = action.payload;
        },
    },
});
export const { setIsDisabledMainCharacterActionControl, setHeldActionKeys } = mainCharacterActionSlice.actions;
export const mainCharacterActionReducer = mainCharacterActionSlice.reducer;
const makeStore = () => {
    return configureStore({
        reducer: {
            [KEYBOARD_EVENT_PLUGIN_ID]: keyboardEventReducer,
            [MAIN_CHARACTER_ACTION_CONTROL_MODULE_ID]: mainCharacterActionReducer,
        },
    });
};
