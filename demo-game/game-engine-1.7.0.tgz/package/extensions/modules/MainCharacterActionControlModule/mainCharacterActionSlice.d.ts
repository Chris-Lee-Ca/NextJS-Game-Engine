import type { PayloadAction } from "@reduxjs/toolkit";
export interface MainCharacterActionStateInterface {
    disabled: boolean;
    heldActionKeys: string[];
}
export declare const mainCharacterActionSlice: import("@reduxjs/toolkit").Slice<MainCharacterActionStateInterface, {
    setIsDisabledMainCharacterActionControl: (state: import("immer").WritableDraft<MainCharacterActionStateInterface>, action: PayloadAction<boolean>) => void;
    setHeldActionKeys: (state: import("immer").WritableDraft<MainCharacterActionStateInterface>, action: PayloadAction<string[]>) => void;
}, "mainCharacter", "mainCharacter", import("@reduxjs/toolkit").SliceSelectors<MainCharacterActionStateInterface>>;
export declare const setIsDisabledMainCharacterActionControl: import("@reduxjs/toolkit").ActionCreatorWithPayload<boolean, "mainCharacter/setIsDisabledMainCharacterActionControl">, setHeldActionKeys: import("@reduxjs/toolkit").ActionCreatorWithPayload<string[], "mainCharacter/setHeldActionKeys">;
export declare const mainCharacterActionReducer: import("redux").Reducer<MainCharacterActionStateInterface>;
declare const makeStore: () => import("@reduxjs/toolkit").EnhancedStore<{
    "keyboard-control": import("../../plugins/keyboardEventPlugin/keyboardEventSlice").KeyboardEventStateInterface;
    "main-character-action-control": MainCharacterActionStateInterface;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<{
        "keyboard-control": import("../../plugins/keyboardEventPlugin/keyboardEventSlice").KeyboardEventStateInterface;
        "main-character-action-control": MainCharacterActionStateInterface;
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
export type AppStore = ReturnType<typeof makeStore>;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];
export {};
