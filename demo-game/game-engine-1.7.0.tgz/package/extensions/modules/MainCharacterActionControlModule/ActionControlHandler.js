import { setHeldActionKeys } from "./mainCharacterActionSlice";
import { KEYBOARD_EVENT_PLUGIN_ID } from "../../plugins/keyboardEventPlugin";
import { MAIN_CHARACTER_ACTION_CONTROL_MODULE_ID } from "./constants";
export class ActionControlHandler {
    constructor({ store, dispatch, actionKeyMapping }) {
        this.pluginId = KEYBOARD_EVENT_PLUGIN_ID;
        this.moduleId = MAIN_CHARACTER_ACTION_CONTROL_MODULE_ID;
        this.store = store;
        this.dispatch = dispatch;
        this.invertedKeyMapping = this.getInvertedActionKeyMapping(actionKeyMapping);
    }
    getInvertedActionKeyMapping(actionKeyMapping) {
        const invertedKeyMapping = {};
        Object.entries(actionKeyMapping).forEach(([keyType, keys]) => {
            keys.forEach((keyboardKey) => {
                if (keyboardKey in invertedKeyMapping) {
                    throw Error(`Keyboard Key: ${keyboardKey} is defined twice in ActionControlHandler`);
                }
                invertedKeyMapping[keyboardKey] = keyType;
            });
        });
        return invertedKeyMapping;
    }
    init() { }
    deinit() { }
    update(_deltaTime) {
        const state = this.store.getState();
        const prevKeys = state[MAIN_CHARACTER_ACTION_CONTROL_MODULE_ID].heldActionKeys;
        if (state[MAIN_CHARACTER_ACTION_CONTROL_MODULE_ID].disabled) {
            if (prevKeys.length > 0)
                this.dispatch(setHeldActionKeys([]));
            return;
        }
        const heldActionKeys = this.getHeldActionKeys(state);
        if (heldActionKeys.length !== prevKeys.length ||
            heldActionKeys.some((k, i) => k !== prevKeys[i])) {
            this.dispatch(setHeldActionKeys(heldActionKeys));
        }
    }
    getHeldActionKeys(state) {
        const heldKeys = state[KEYBOARD_EVENT_PLUGIN_ID].heldKeys;
        const heldActionKeys = heldKeys
            .filter((key) => key in this.invertedKeyMapping)
            .map((key) => this.invertedKeyMapping[key]);
        return heldActionKeys;
    }
}
export default ActionControlHandler;
