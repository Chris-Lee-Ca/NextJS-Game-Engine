import { configureStore, createSlice } from "@reduxjs/toolkit";
import { KEYBOARD_EVENT_PLUGIN_ID, keyboardEventReducer } from "../../plugins/keyboardEventPlugin";
import { MAIN_CHARACTER_DIRECTION_CONTROL_MODULE_ID } from "./constants";
const initialState = {
    disabled: false,
    movementDirection: "",
};
export const mainCharacterDirectionSlice = createSlice({
    name: "mainCharacter",
    initialState,
    reducers: {
        setIsDisabledMainCharacterControl: (state, action) => {
            state.disabled = action.payload;
        },
        setMovmentDirection: (state, action) => {
            state.movementDirection = action.payload;
        },
    },
});
export const { setIsDisabledMainCharacterControl, setMovmentDirection } = mainCharacterDirectionSlice.actions;
export const mainCharacterDirectionReducer = mainCharacterDirectionSlice.reducer;
const makeStore = () => {
    return configureStore({
        reducer: {
            [KEYBOARD_EVENT_PLUGIN_ID]: keyboardEventReducer,
            [MAIN_CHARACTER_DIRECTION_CONTROL_MODULE_ID]: mainCharacterDirectionReducer,
        },
    });
};
