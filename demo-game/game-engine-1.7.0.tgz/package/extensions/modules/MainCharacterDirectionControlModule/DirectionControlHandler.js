import { MAIN_CHARACTER_DIRECTION_CONTROL_MODULE_ID } from "./constants";
import { setMovmentDirection } from "./mainCharacterSlice";
import { KEYBOARD_EVENT_PLUGIN_ID } from "../../plugins/keyboardEventPlugin";
export class DirectionControlHandler {
    constructor({ store, dispatch, directionKeyMapping }) {
        this.pluginId = KEYBOARD_EVENT_PLUGIN_ID;
        this.moduleId = MAIN_CHARACTER_DIRECTION_CONTROL_MODULE_ID;
        this.store = store;
        this.dispatch = dispatch;
        this.invertedKeyMapping = this.getInvertedKeyMapping(directionKeyMapping);
    }
    getInvertedKeyMapping(directionKeyMapping) {
        const invertedKeyMapping = {};
        Object.entries(directionKeyMapping).forEach(([keyType, keys]) => {
            keys.forEach((keyboardKey) => {
                if (keyboardKey in invertedKeyMapping) {
                    throw Error(`Keyboard Key: ${keyboardKey} is defined twice in ActionControlHandler`);
                }
                invertedKeyMapping[keyboardKey] = keyType;
            });
        });
        return invertedKeyMapping;
    }
    init() { }
    deinit() { }
    update(deltaTime) {
        const state = this.store.getState();
        if (state[MAIN_CHARACTER_DIRECTION_CONTROL_MODULE_ID].disabled) {
            this.dispatch(setMovmentDirection(""));
            return;
        }
        const heldDirectionKeys = this.getHeldDirectionKeys(state);
        const movementDirection = this.getActiveDirectionKey(heldDirectionKeys);
        const oldMovmentDirection = state[MAIN_CHARACTER_DIRECTION_CONTROL_MODULE_ID].movementDirection;
        if (movementDirection !== oldMovmentDirection) {
            this.dispatch(setMovmentDirection(movementDirection));
        }
    }
    getHeldDirectionKeys(state) {
        const heldKeys = state[KEYBOARD_EVENT_PLUGIN_ID].heldKeys;
        const heldDirectionKeys = heldKeys
            .filter((key) => key in this.invertedKeyMapping)
            .map((key) => this.invertedKeyMapping[key]);
        return heldDirectionKeys;
    }
    getActiveDirectionKey(heldDirectionKeys) {
        if (heldDirectionKeys.length === 0)
            return "";
        return heldDirectionKeys[0];
    }
}
export default DirectionControlHandler;
