import type { PayloadAction } from "@reduxjs/toolkit";
import { DirectionCommand } from "./types";
export interface MainCharacterStateInterface {
    disabled: boolean;
    movementDirection: DirectionCommand;
}
export declare const mainCharacterDirectionSlice: import("@reduxjs/toolkit").Slice<MainCharacterStateInterface, {
    setIsDisabledMainCharacterControl: (state: import("immer").WritableDraft<MainCharacterStateInterface>, action: PayloadAction<boolean>) => void;
    setMovmentDirection: (state: import("immer").WritableDraft<MainCharacterStateInterface>, action: PayloadAction<DirectionCommand>) => void;
}, "mainCharacter", "mainCharacter", import("@reduxjs/toolkit").SliceSelectors<MainCharacterStateInterface>>;
export declare const setIsDisabledMainCharacterControl: import("@reduxjs/toolkit").ActionCreatorWithPayload<boolean, "mainCharacter/setIsDisabledMainCharacterControl">, setMovmentDirection: import("@reduxjs/toolkit").ActionCreatorWithPayload<DirectionCommand, "mainCharacter/setMovmentDirection">;
export declare const mainCharacterDirectionReducer: import("redux").Reducer<MainCharacterStateInterface>;
declare const makeStore: () => import("@reduxjs/toolkit").EnhancedStore<{
    "keyboard-control": import("../../plugins/keyboardEventPlugin/keyboardEventSlice").KeyboardEventStateInterface;
    "main-character-direction-control": MainCharacterStateInterface;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<{
        "keyboard-control": import("../../plugins/keyboardEventPlugin/keyboardEventSlice").KeyboardEventStateInterface;
        "main-character-direction-control": MainCharacterStateInterface;
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
export type AppStore = ReturnType<typeof makeStore>;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];
export {};
