import GridHelper from "../../../helper/GridHelper";
import { DIRECTION_COMMAND_MAPPING } from "./constants";
export const getCharacterOffset = (directionCommand, movingSpeed, deltaTime) => {
    const movementDirection = DIRECTION_COMMAND_MAPPING[directionCommand];
    const gridSize = GridHelper.getGridSizeInPixel();
    const movementPerLoop = (movingSpeed * deltaTime) / gridSize;
    return {
        x: movementDirection.x * movementPerLoop,
        y: movementDirection.y * movementPerLoop,
    };
};
