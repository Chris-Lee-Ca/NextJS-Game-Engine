import { Vector2 } from "../../../types/general";
import { DirectionCommand } from "./types";
export declare const getCharacterOffset: (directionCommand: DirectionCommand, movingSpeed: number, deltaTime: number) => Vector2;
