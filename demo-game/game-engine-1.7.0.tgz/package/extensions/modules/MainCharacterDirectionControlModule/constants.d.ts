import { Direction } from "../../../types/general";
import { KeyboardKey } from "../../plugins/keyboardEventPlugin";
import { DirectionCommand } from "./types";
export declare const MAIN_CHARACTER_DIRECTION_CONTROL_MODULE_ID = "main-character-direction-control";
export declare const DIRECTION_KEYS: DirectionCommand[];
export declare const DEFAULT_DIRECTION_KEY_MAPPING: {
    [key in DirectionCommand]?: KeyboardKey[];
};
export declare const DIRECTION_COMMAND_MAPPING: {
    [key in DirectionCommand]: Direction;
};
