import ModuleHandler from "../ModuleHandler";
import { AppDispatch, AppStore } from "./mainCharacterSlice";
import { DirectionKeyMapping } from "./types";
export interface DirectionControlHandlerConfig {
    store: AppStore;
    dispatch: AppDispatch;
    directionKeyMapping: DirectionKeyMapping;
}
export declare class DirectionControlHandler implements ModuleHandler {
    pluginId: string;
    moduleId: string;
    private store;
    private dispatch;
    private invertedKeyMapping;
    constructor({ store, dispatch, directionKeyMapping }: DirectionControlHandlerConfig);
    private getInvertedKeyMapping;
    init(): void;
    deinit(): void;
    update(deltaTime: number): void;
    private getHeldDirectionKeys;
    private getActiveDirectionKey;
}
export default DirectionControlHandler;
