export const MAIN_CHARACTER_DIRECTION_CONTROL_MODULE_ID = "main-character-direction-control";
export const DIRECTION_KEYS = ["up", "down", "left", "right"];
export const DEFAULT_DIRECTION_KEY_MAPPING = {
    up: ["ArrowUp", "w"],
    down: ["ArrowDown", "s"],
    left: ["ArrowLeft", "a"],
    right: ["ArrowRight", "d"],
};
export const DIRECTION_COMMAND_MAPPING = {
    up: { x: 0, y: -1 },
    down: { x: 0, y: 1 },
    left: { x: -1, y: 0 },
    right: { x: 1, y: 0 },
    "": { x: 0, y: 0 },
};
