import type { PayloadAction } from "@reduxjs/toolkit";
interface RunState {
    isRunning: boolean;
}
export declare const runSlice: import("@reduxjs/toolkit").Slice<RunState, {
    setIsRunning: (state: import("immer").WritableDraft<RunState>, action: PayloadAction<boolean>) => void;
}, "run", "run", import("@reduxjs/toolkit").SliceSelectors<RunState>>;
export declare const setIsRunning: import("@reduxjs/toolkit").ActionCreatorWithPayload<boolean, "run/setIsRunning">;
export declare const runReducer: import("redux").Reducer<RunState>;
export {};
