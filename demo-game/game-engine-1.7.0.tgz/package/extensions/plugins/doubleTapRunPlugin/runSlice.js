// Redux slice that holds the run-mode flag.
// DoubleTapRunHandler dispatches setIsRunning; MainCharacter reads isRunning to adjust speed.
import { createSlice } from "@reduxjs/toolkit";
const initialState = {
    isRunning: false,
};
export const runSlice = createSlice({
    name: "run",
    initialState,
    reducers: {
        setIsRunning: (state, action) => {
            state.isRunning = action.payload;
        },
    },
});
export const { setIsRunning } = runSlice.actions;
export const runReducer = runSlice.reducer;
