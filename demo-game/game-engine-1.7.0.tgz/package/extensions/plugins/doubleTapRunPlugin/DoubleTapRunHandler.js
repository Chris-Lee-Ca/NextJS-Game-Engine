import { DOUBLE_TAP_RUN_PLUGIN_ID, DEFAULT_DIRECTION_KEYS, MOBILE_GRACE_PERIOD_MS } from "./constants";
import { createInitialState, onKeyDown, onKeyUp } from "./doubleTapLogic";
import { setIsRunning } from "./runSlice";
export class DoubleTapRunHandler {
    constructor({ dispatch, directionKeys, getIsBlocked, gracePeriodMs }) {
        this.pluginId = DOUBLE_TAP_RUN_PLUGIN_ID;
        // Tracks which direction keys are currently held so run is not cancelled during a finger-swap.
        this.heldDirectionKeys = new Set();
        // Pending timer to cancel run after all keys are released; cleared if a key is pressed again within gracePeriodMs.
        this.cancelRunTimer = null;
        this._onKeyDown = (e) => {
            if (e.repeat)
                return;
            this.handleKeyDown(e.key);
        };
        this._onKeyUp = (e) => {
            this.handleKeyUp(e.key, e.isTrusted);
        };
        this.dispatch = dispatch;
        this.directionKeys = directionKeys !== null && directionKeys !== void 0 ? directionKeys : DEFAULT_DIRECTION_KEYS;
        this.getIsBlocked = getIsBlocked !== null && getIsBlocked !== void 0 ? getIsBlocked : (() => false);
        this.gracePeriodMs = gracePeriodMs !== null && gracePeriodMs !== void 0 ? gracePeriodMs : MOBILE_GRACE_PERIOD_MS;
        this.doubleTapState = createInitialState();
    }
    init() {
        if (typeof window === "undefined")
            return;
        window.addEventListener("keydown", this._onKeyDown);
        window.addEventListener("keyup", this._onKeyUp);
    }
    deinit() {
        if (typeof window === "undefined")
            return;
        window.removeEventListener("keydown", this._onKeyDown);
        window.removeEventListener("keyup", this._onKeyUp);
    }
    update(_deltaTime) { }
    handleKeyDown(key) {
        if (!this.directionKeys.has(key))
            return;
        // Cancel any pending run-cancel (handles mobile finger-swap gap)
        if (this.cancelRunTimer !== null) {
            clearTimeout(this.cancelRunTimer);
            this.cancelRunTimer = null;
        }
        this.heldDirectionKeys.add(key);
        // Don't start a new run while a modal or dialog is blocking input
        if (this.getIsBlocked())
            return;
        const { nextState, triggered } = onKeyDown(this.doubleTapState, key, Date.now());
        this.doubleTapState = nextState;
        if (triggered)
            this.dispatch(setIsRunning(true));
    }
    handleKeyUp(key, isTrusted) {
        if (!this.directionKeys.has(key))
            return;
        this.doubleTapState = onKeyUp(this.doubleTapState, key, Date.now());
        this.heldDirectionKeys.delete(key);
        if (this.heldDirectionKeys.size === 0) {
            if (isTrusted) {
                // Real keyboard: cancel run immediately, no grace period
                this.dispatch(setIsRunning(false));
            }
            else {
                // Virtual keyboard: grace period lets users swap fingers without dropping run mode
                this.cancelRunTimer = setTimeout(() => {
                    this.cancelRunTimer = null;
                    this.dispatch(setIsRunning(false));
                }, this.gracePeriodMs);
            }
        }
    }
}
export default DoubleTapRunHandler;
