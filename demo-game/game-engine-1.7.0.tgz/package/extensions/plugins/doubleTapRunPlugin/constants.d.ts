export declare const DOUBLE_TAP_RUN_PLUGIN_ID = "double-tap-run";
export declare const DOUBLE_TAP_WINDOW_MS = 300;
export declare const MIN_TAP_DURATION_MS = 30;
export declare const MAX_TAP_DURATION_MS = 250;
export declare const MOBILE_GRACE_PERIOD_MS = 400;
export declare const DEFAULT_DIRECTION_KEYS: Set<string>;
