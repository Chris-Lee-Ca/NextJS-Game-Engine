import PluginHandler from "../PluginHandler";
import { setIsRunning } from "./runSlice";
export interface DoubleTapRunHandlerConfig {
    dispatch: (action: ReturnType<typeof setIsRunning>) => void;
    directionKeys?: Set<string>;
    getIsBlocked?: () => boolean;
    gracePeriodMs?: number;
}
export declare class DoubleTapRunHandler implements PluginHandler {
    pluginId: string;
    private dispatch;
    private directionKeys;
    private getIsBlocked;
    private gracePeriodMs;
    private doubleTapState;
    private heldDirectionKeys;
    private cancelRunTimer;
    constructor({ dispatch, directionKeys, getIsBlocked, gracePeriodMs }: DoubleTapRunHandlerConfig);
    init(): void;
    deinit(): void;
    update(_deltaTime: number): void;
    private _onKeyDown;
    private _onKeyUp;
    private handleKeyDown;
    private handleKeyUp;
}
export default DoubleTapRunHandler;
