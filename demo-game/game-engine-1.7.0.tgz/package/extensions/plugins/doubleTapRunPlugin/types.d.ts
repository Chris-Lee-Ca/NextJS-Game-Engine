export interface DoubleTapState {
    key: string;
    keyDownTime: number;
    keyUpTime: number;
}
export interface KeyDownResult {
    nextState: DoubleTapState;
    triggered: boolean;
}
