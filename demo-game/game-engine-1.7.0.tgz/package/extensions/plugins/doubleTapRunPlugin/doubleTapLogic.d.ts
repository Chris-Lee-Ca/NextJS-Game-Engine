import { DoubleTapState, KeyDownResult } from "./types";
export declare const createInitialState: () => DoubleTapState;
export declare function onKeyDown(state: DoubleTapState, key: string, now: number): KeyDownResult;
export declare function onKeyUp(state: DoubleTapState, key: string, now: number): DoubleTapState;
