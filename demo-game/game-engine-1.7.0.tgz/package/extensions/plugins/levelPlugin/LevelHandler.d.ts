import { AppDispatch, AppStore } from "./levelSlice";
import { AllLevelInfo } from "./types";
import { GameObjectFactory } from "../../../components/GameObjectFactory";
import PluginHandler from "../PluginHandler";
export interface LevelHandlerConfig {
    store: AppStore;
    dispatch: AppDispatch;
    gameObjectFactory: GameObjectFactory;
    currentLevel: string;
    allLevelInfo: AllLevelInfo;
}
export declare class LevelHandler implements PluginHandler {
    pluginId: string;
    private store;
    private dispatch;
    private objectPool;
    private gameObjectFactory;
    private previousLevelInfo;
    constructor({ store, dispatch, gameObjectFactory, currentLevel, allLevelInfo }: LevelHandlerConfig);
    init(): void;
    loadLevel(): void;
    deinit(): void;
    update(_deltaTime: number): void;
    private createMapBoundry;
    private createGameObject;
    private createInvisibleWall;
}
