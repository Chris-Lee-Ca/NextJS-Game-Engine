export declare const LEVEL_PLUGIN_ID = "level";
