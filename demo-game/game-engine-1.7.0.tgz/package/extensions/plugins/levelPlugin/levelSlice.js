import { configureStore, createSlice } from "@reduxjs/toolkit";
import { LEVEL_PLUGIN_ID } from "./constants";
import { coreReducer } from "../../../redux/features/coreSlice";
const initialState = {
    currentLevel: "",
    allLevelInfo: {},
};
export const levelSlice = createSlice({
    name: "level",
    initialState,
    reducers: {
        setCurrentLevel: (state, action) => {
            state.currentLevel = action.payload;
        },
        setAllLevelInfo: (state, action) => {
            state.allLevelInfo = action.payload;
        },
        setLevelInfoByKey: (state, action) => {
            state.allLevelInfo[action.payload.key] = action.payload.levelInfo;
        },
    },
});
export const selectCurrentLevelInfo = (state) => {
    const currentLevel = state[LEVEL_PLUGIN_ID].currentLevel;
    return state.level.allLevelInfo[currentLevel];
};
export const updateCurrentLevelInfo = (levelInfo) => (dispatch) => {
    dispatch(setLevelInfoByKey({ key: levelInfo.levelTitle, levelInfo: levelInfo }));
    dispatch(setCurrentLevel(levelInfo.levelTitle));
};
export const { setCurrentLevel, setAllLevelInfo, setLevelInfoByKey } = levelSlice.actions;
export const levelReducer = levelSlice.reducer;
const makeStore = () => {
    return configureStore({
        reducer: {
            core: coreReducer,
            [LEVEL_PLUGIN_ID]: levelReducer,
        },
    });
};
