import { Placement, Vector2 } from "../../../types/general";
import { LevelInfo } from "./types";
import GameObject from "../../../components/GameObject";
export declare class CanvasHelper {
    static getCanvasBaseOffset(): Vector2;
    static getCanvasOffset(mainCharacter: GameObject): {
        x: number;
        y: number;
    };
    /**
     * Finds the main character in the level information placements.
     * @param {LevelInfo} levelInfo - The information about the level, including placements.
     * @returns {string} - The placement id for the main character.
     * @throws {Error} - If the main character is not defined in the level.
     */
    static findMainCharacter(levelInfo: LevelInfo): Placement;
}
