export declare const KEYBOARD_EVENT_PLUGIN_ID = "keyboard-control";
