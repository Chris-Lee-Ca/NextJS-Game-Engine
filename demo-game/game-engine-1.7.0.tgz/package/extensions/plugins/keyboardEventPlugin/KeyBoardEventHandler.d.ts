import { AppDispatch } from "./keyboardEventSlice";
import PluginHandler from "../PluginHandler";
export interface KeyboardEventHandlerConfig {
    dispatch: AppDispatch;
}
export declare class KeyboardEventHandler implements PluginHandler {
    pluginId: string;
    private dispatch;
    private heldKeys;
    constructor({ dispatch }: KeyboardEventHandlerConfig);
    init(): void;
    deinit(): void;
    update(deltaTime: number): void;
    private handleKeyUp;
    private handleKeyDown;
    private handleWindowFocus;
}
