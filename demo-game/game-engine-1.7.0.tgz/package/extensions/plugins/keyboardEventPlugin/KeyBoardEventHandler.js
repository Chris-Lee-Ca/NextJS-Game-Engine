import { setHeldKeys } from "./keyboardEventSlice";
import { KEYBOARD_EVENT_PLUGIN_ID } from "./constants";
export class KeyboardEventHandler {
    constructor({ dispatch }) {
        this.pluginId = KEYBOARD_EVENT_PLUGIN_ID;
        this.heldKeys = [];
        this.handleKeyUp = (event) => {
            const key = event.key;
            this.heldKeys = this.heldKeys.filter((heldkey) => heldkey !== key);
            this.dispatch(setHeldKeys(this.heldKeys));
        };
        this.handleKeyDown = (event) => {
            const key = event.key;
            if (!this.heldKeys.includes(key)) {
                this.heldKeys.unshift(key);
            }
            this.dispatch(setHeldKeys(this.heldKeys));
        };
        this.handleWindowFocus = () => {
            // Reset heldKeys to ensure accurate state when returning to the window
            this.heldKeys = [];
            this.dispatch(setHeldKeys(this.heldKeys));
        };
        this.dispatch = dispatch;
    }
    init() {
        if (typeof window !== "undefined") {
            window.addEventListener("keyup", this.handleKeyUp);
            window.addEventListener("keydown", this.handleKeyDown);
            window.addEventListener("focus", this.handleWindowFocus);
        }
    }
    deinit() {
        if (typeof window !== "undefined") {
            window.removeEventListener("keyup", this.handleKeyUp);
            window.removeEventListener("keydown", this.handleKeyDown);
            window.removeEventListener("focus", this.handleWindowFocus);
        }
    }
    update(deltaTime) { }
}
