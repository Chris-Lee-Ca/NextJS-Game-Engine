import { createSlice } from "@reduxjs/toolkit";
import { configureStore } from "@reduxjs/toolkit";
import { KEYBOARD_EVENT_PLUGIN_ID } from "./constants";
const initialState = {
    heldKeys: [],
};
export const keyboardEventSlice = createSlice({
    name: "keyboardEvent",
    initialState,
    reducers: {
        setHeldKeys: (state, action) => {
            state.heldKeys = [...action.payload];
        },
    },
});
export const { setHeldKeys } = keyboardEventSlice.actions;
export const keyboardEventReducer = keyboardEventSlice.reducer;
const makeStore = () => {
    return configureStore({
        reducer: {
            [KEYBOARD_EVENT_PLUGIN_ID]: keyboardEventReducer,
        },
    });
};
