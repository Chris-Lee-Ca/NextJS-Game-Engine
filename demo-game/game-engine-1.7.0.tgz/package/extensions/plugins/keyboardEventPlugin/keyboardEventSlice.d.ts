import type { PayloadAction } from "@reduxjs/toolkit";
import { KeyboardKey } from "./types";
export interface KeyboardEventStateInterface {
    heldKeys: KeyboardKey[];
}
export declare const keyboardEventSlice: import("@reduxjs/toolkit").Slice<KeyboardEventStateInterface, {
    setHeldKeys: (state: import("immer").WritableDraft<KeyboardEventStateInterface>, action: PayloadAction<KeyboardKey[]>) => void;
}, "keyboardEvent", "keyboardEvent", import("@reduxjs/toolkit").SliceSelectors<KeyboardEventStateInterface>>;
export declare const setHeldKeys: import("@reduxjs/toolkit").ActionCreatorWithPayload<KeyboardKey[], "keyboardEvent/setHeldKeys">;
export declare const keyboardEventReducer: import("redux").Reducer<KeyboardEventStateInterface>;
declare const makeStore: () => import("@reduxjs/toolkit").EnhancedStore<{
    "keyboard-control": KeyboardEventStateInterface;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<{
        "keyboard-control": KeyboardEventStateInterface;
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
export type AppStore = ReturnType<typeof makeStore>;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];
export {};
