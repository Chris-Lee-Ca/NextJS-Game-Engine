import { configureStore, createSlice } from "@reduxjs/toolkit";
import { AUDIO_PLUGIN_ID } from "./constants";
const initialState = {
    masterVolume: 0.7,
    muted: false,
};
export const audioSlice = createSlice({
    name: "audio",
    initialState,
    reducers: {
        setMasterVolume: (state, action) => {
            state.masterVolume = Math.max(0, Math.min(1, action.payload));
        },
        setMuted: (state, action) => {
            state.muted = action.payload;
        },
    },
});
export const { setMasterVolume, setMuted } = audioSlice.actions;
export const audioReducer = audioSlice.reducer;
const makeStore = () => {
    return configureStore({
        reducer: {
            [AUDIO_PLUGIN_ID]: audioReducer,
        },
    });
};
