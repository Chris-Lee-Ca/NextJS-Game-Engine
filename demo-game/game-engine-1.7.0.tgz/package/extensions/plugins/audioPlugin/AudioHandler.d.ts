import PluginHandler from "../PluginHandler";
import { AppStore } from "./audioSlice";
import { BgmConfig, SfxConfig } from "./types";
export interface AudioHandlerConfig {
    store: AppStore;
}
export declare function getAudioHandler(): AudioHandler | null;
export declare function preloadSfx(id: string, src: string): void;
export declare class AudioHandler implements PluginHandler {
    pluginId: string;
    private store;
    private audioContext;
    /** Controls overall output volume and mute. */
    private masterGain;
    /** Sits between BGM sources and masterGain — zeroed during "block" SFX, leaving SFX unaffected. */
    private bgmGain;
    private bgmConfig;
    private bgmOscillators;
    private bgmLFOs;
    private bgmElement;
    private bgmStarted;
    private shouldPlayBgm;
    /** Counts how many "block" SFX are currently playing. BGM only resumes when this reaches 0. */
    private bgmBlockCount;
    /** src paths waiting for AudioContext to be ready before decoding. */
    private sfxPending;
    /** Decoded AudioBuffers keyed by the id passed to preloadSfx(). */
    private sfxBuffers;
    constructor({ store }: AudioHandlerConfig);
    init(): void;
    deinit(): void;
    update(_deltaTime: number): void;
    /**
     * Preload an audio file so it can be played instantly with playSfxDirect({ type: "file", id }).
     * Safe to call before the AudioContext exists — decoding happens automatically after first
     * user interaction.
     */
    preloadSfx(id: string, src: string): void;
    playSfxDirect(config: SfxConfig): void;
    startBgm(config: BgmConfig): void;
    stopBgm(): void;
    private resumeContext;
    private _playFileSfx;
    private _playSynthSfx;
    private _blockBgm;
    private _unblockBgm;
    private _doStartBgm;
    private _startFileBgm;
    private _stopFileBgm;
    private _startSynthBgm;
    private _stopSynthBgm;
    private _decodeAndCache;
}
