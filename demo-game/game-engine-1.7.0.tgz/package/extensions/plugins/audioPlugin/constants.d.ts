export declare const AUDIO_PLUGIN_ID = "audio";
