import type { PayloadAction } from "@reduxjs/toolkit";
export interface AudioState {
    masterVolume: number;
    muted: boolean;
}
export declare const audioSlice: import("@reduxjs/toolkit").Slice<AudioState, {
    setMasterVolume: (state: import("immer").WritableDraft<AudioState>, action: PayloadAction<number>) => void;
    setMuted: (state: import("immer").WritableDraft<AudioState>, action: PayloadAction<boolean>) => void;
}, "audio", "audio", import("@reduxjs/toolkit").SliceSelectors<AudioState>>;
export declare const setMasterVolume: import("@reduxjs/toolkit").ActionCreatorWithPayload<number, "audio/setMasterVolume">, setMuted: import("@reduxjs/toolkit").ActionCreatorWithPayload<boolean, "audio/setMuted">;
export declare const audioReducer: import("redux").Reducer<AudioState>;
declare const makeStore: () => import("@reduxjs/toolkit").EnhancedStore<{
    audio: AudioState;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<{
        audio: AudioState;
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
export type AppStore = ReturnType<typeof makeStore>;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];
export {};
