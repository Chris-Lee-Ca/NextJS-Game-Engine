var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { AUDIO_PLUGIN_ID } from "./constants";
const BGM_FADE_IN_SECONDS = 3;
let _instance = null;
const _pendingPreloads = [];
export function getAudioHandler() {
    return _instance;
}
// Safe to call at any time — including before AudioHandler.init() has run.
// Calls registered before init() are queued and flushed automatically on init.
export function preloadSfx(id, src) {
    if (_instance) {
        _instance.preloadSfx(id, src);
    }
    else {
        _pendingPreloads.push({ id, src });
    }
}
export class AudioHandler {
    constructor({ store }) {
        this.pluginId = AUDIO_PLUGIN_ID;
        this.audioContext = null;
        /** Controls overall output volume and mute. */
        this.masterGain = null;
        /** Sits between BGM sources and masterGain — zeroed during "block" SFX, leaving SFX unaffected. */
        this.bgmGain = null;
        this.bgmConfig = null;
        this.bgmOscillators = [];
        this.bgmLFOs = [];
        this.bgmElement = null;
        this.bgmStarted = false;
        this.shouldPlayBgm = false;
        /** Counts how many "block" SFX are currently playing. BGM only resumes when this reaches 0. */
        this.bgmBlockCount = 0;
        /** src paths waiting for AudioContext to be ready before decoding. */
        this.sfxPending = new Map();
        /** Decoded AudioBuffers keyed by the id passed to preloadSfx(). */
        this.sfxBuffers = new Map();
        // ── private ─────────────────────────────────────────────────────────────
        this.resumeContext = () => {
            if (!this.audioContext) {
                this.audioContext = new AudioContext();
                this.bgmGain = this.audioContext.createGain();
                this.masterGain = this.audioContext.createGain();
                this.bgmGain.connect(this.masterGain);
                this.masterGain.connect(this.audioContext.destination);
                const state = this.store.getState()[AUDIO_PLUGIN_ID];
                this.masterGain.gain.value = state.muted ? 0 : state.masterVolume;
            }
            if (this.audioContext.state === "suspended") {
                this.audioContext.resume();
            }
            // Decode any SFX files that were registered before the context existed.
            this.sfxPending.forEach((src, id) => this._decodeAndCache(id, src));
            this.sfxPending.clear();
            // BGM NOT started here — update() handles it on the next frame.
        };
        this.store = store;
    }
    init() {
        _instance = this;
        _pendingPreloads.forEach(({ id, src }) => this.preloadSfx(id, src));
        _pendingPreloads.length = 0;
        if (typeof window === "undefined")
            return;
        // These listeners only create the AudioContext (browser autoplay policy).
        // BGM is started separately via update() once the context is running.
        window.addEventListener("click", this.resumeContext, { once: true });
        window.addEventListener("keydown", this.resumeContext, { once: true });
        window.addEventListener("touchstart", this.resumeContext, { once: true });
    }
    deinit() {
        _instance = null;
        if (typeof window === "undefined")
            return;
        window.removeEventListener("click", this.resumeContext);
        window.removeEventListener("keydown", this.resumeContext);
        window.removeEventListener("touchstart", this.resumeContext);
        this.stopBgm();
        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
            this.masterGain = null;
            this.bgmGain = null;
        }
        this.sfxBuffers.clear();
        this.sfxPending.clear();
    }
    update(_deltaTime) {
        if (!this.audioContext || !this.masterGain)
            return;
        const state = this.store.getState()[AUDIO_PLUGIN_ID];
        const effectiveVolume = state.muted ? 0 : state.masterVolume;
        this.masterGain.gain.setTargetAtTime(effectiveVolume, this.audioContext.currentTime, 0.05);
        // Auto-start BGM once AudioContext is running — never from within the event listener,
        // so arbitrary key presses don't feel like they trigger a sound effect.
        if (this.shouldPlayBgm && !this.bgmStarted && this.audioContext.state === "running") {
            this._doStartBgm();
        }
    }
    /**
     * Preload an audio file so it can be played instantly with playSfxDirect({ type: "file", id }).
     * Safe to call before the AudioContext exists — decoding happens automatically after first
     * user interaction.
     */
    preloadSfx(id, src) {
        if (this.audioContext && this.audioContext.state === "running") {
            this._decodeAndCache(id, src);
        }
        else {
            this.sfxPending.set(id, src);
        }
    }
    playSfxDirect(config) {
        if (!this.audioContext || !this.masterGain)
            return;
        if (config.type === "file") {
            this._playFileSfx(config);
        }
        else {
            this._playSynthSfx(config);
        }
    }
    startBgm(config) {
        this.bgmConfig = config;
        this.shouldPlayBgm = true;
        // Actual start happens in update() once AudioContext is confirmed running.
    }
    stopBgm() {
        this.shouldPlayBgm = false;
        this.bgmStarted = false;
        this.bgmBlockCount = 0;
        this._stopSynthBgm();
        this._stopFileBgm();
    }
    _playFileSfx(config) {
        var _a;
        const buffer = this.sfxBuffers.get(config.id);
        if (!buffer || !this.audioContext || !this.masterGain)
            return;
        const source = this.audioContext.createBufferSource();
        const gain = this.audioContext.createGain();
        source.buffer = buffer;
        gain.gain.value = (_a = config.volume) !== null && _a !== void 0 ? _a : 1.0;
        source.connect(gain);
        gain.connect(this.masterGain);
        source.start();
        if (config.bgmBehavior === "block") {
            this._blockBgm();
            source.onended = () => {
                this._unblockBgm();
                gain.disconnect();
            };
        }
        else {
            source.onended = () => { gain.disconnect(); };
        }
    }
    _playSynthSfx(config) {
        if (!this.audioContext || !this.masterGain)
            return;
        const ctx = this.audioContext;
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = config.type;
        osc.frequency.setValueAtTime(config.frequency, now);
        if (config.endFrequency !== undefined) {
            osc.frequency.linearRampToValueAtTime(config.endFrequency, now + config.duration);
        }
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(config.volume, now + 0.005);
        gain.gain.setValueAtTime(config.volume, now + config.duration - 0.01);
        gain.gain.linearRampToValueAtTime(0, now + config.duration);
        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(now);
        osc.stop(now + config.duration);
        if (config.bgmBehavior === "block") {
            this._blockBgm();
            osc.onended = () => {
                this._unblockBgm();
                gain.disconnect();
                osc.disconnect();
            };
        }
        else {
            osc.onended = () => {
                gain.disconnect();
                osc.disconnect();
            };
        }
    }
    _blockBgm() {
        var _a;
        this.bgmBlockCount++;
        if (this.bgmBlockCount > 1)
            return;
        if (((_a = this.bgmConfig) === null || _a === void 0 ? void 0 : _a.type) === "file" && this.bgmElement) {
            this.bgmElement.pause();
        }
        else if (this.bgmGain && this.audioContext) {
            this.bgmGain.gain.setTargetAtTime(0, this.audioContext.currentTime, 0.02);
        }
    }
    _unblockBgm() {
        var _a;
        this.bgmBlockCount = Math.max(0, this.bgmBlockCount - 1);
        if (this.bgmBlockCount > 0)
            return;
        if (((_a = this.bgmConfig) === null || _a === void 0 ? void 0 : _a.type) === "file" && this.bgmElement) {
            this.bgmElement.play().catch(() => { });
        }
        else if (this.bgmGain && this.audioContext) {
            this.bgmGain.gain.setTargetAtTime(1, this.audioContext.currentTime, 0.05);
        }
    }
    _doStartBgm() {
        if (!this.bgmConfig)
            return;
        this.bgmStarted = true;
        if (this.bgmConfig.type === "file") {
            this._startFileBgm(this.bgmConfig);
        }
        else {
            this._startSynthBgm(this.bgmConfig);
        }
    }
    _startFileBgm(config) {
        var _a, _b;
        this._stopFileBgm();
        const el = new Audio(config.src);
        el.loop = (_a = config.loop) !== null && _a !== void 0 ? _a : true;
        el.volume = (_b = config.volume) !== null && _b !== void 0 ? _b : 0.5;
        el.play().catch(() => { });
        this.bgmElement = el;
    }
    _stopFileBgm() {
        if (this.bgmElement) {
            this.bgmElement.pause();
            this.bgmElement.src = "";
            this.bgmElement = null;
        }
    }
    _startSynthBgm(config) {
        var _a, _b, _c, _d;
        if (!this.audioContext || !this.bgmGain)
            return;
        this._stopSynthBgm();
        const ctx = this.audioContext;
        const now = ctx.currentTime;
        const targetGain = (_a = config.volume) !== null && _a !== void 0 ? _a : 0.04;
        const waveType = (_b = config.waveType) !== null && _b !== void 0 ? _b : "sine";
        const lfoRate = (_c = config.lfoRate) !== null && _c !== void 0 ? _c : 0.3;
        const lfoDepth = (_d = config.lfoDepth) !== null && _d !== void 0 ? _d : 3;
        this.bgmGain.gain.setValueAtTime(this.bgmBlockCount > 0 ? 0 : 1, now);
        config.frequencies.forEach((freq, i) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            const lfo = ctx.createOscillator();
            const lfoGain = ctx.createGain();
            osc.type = waveType;
            osc.frequency.value = freq;
            osc.detune.value = i % 2 === 0 ? -5 : 5;
            lfo.type = "sine";
            lfo.frequency.value = lfoRate;
            lfoGain.gain.value = lfoDepth;
            lfo.connect(lfoGain);
            lfoGain.connect(osc.detune);
            gain.gain.setValueAtTime(0, now);
            gain.gain.linearRampToValueAtTime(targetGain, now + BGM_FADE_IN_SECONDS);
            osc.connect(gain);
            gain.connect(this.bgmGain);
            lfo.start();
            osc.start();
            this.bgmOscillators.push(osc);
            this.bgmLFOs.push(lfo);
        });
    }
    _stopSynthBgm() {
        this.bgmLFOs.forEach((lfo) => {
            try {
                lfo.stop();
            }
            catch (_) { }
            lfo.disconnect();
        });
        this.bgmOscillators.forEach((osc) => {
            try {
                osc.stop();
            }
            catch (_) { }
            osc.disconnect();
        });
        this.bgmLFOs = [];
        this.bgmOscillators = [];
    }
    _decodeAndCache(id, src) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.audioContext)
                return;
            try {
                const response = yield fetch(src);
                const arrayBuffer = yield response.arrayBuffer();
                const audioBuffer = yield this.audioContext.decodeAudioData(arrayBuffer);
                this.sfxBuffers.set(id, audioBuffer);
            }
            catch (_) {
                // File missing or decode error — fail silently
            }
        });
    }
}
