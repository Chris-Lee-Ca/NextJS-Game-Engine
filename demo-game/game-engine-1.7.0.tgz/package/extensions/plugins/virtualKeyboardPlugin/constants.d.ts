export declare const VIRTUAL_KEYBOARD_PLUGIN_ID = "virtual-keyboard";
