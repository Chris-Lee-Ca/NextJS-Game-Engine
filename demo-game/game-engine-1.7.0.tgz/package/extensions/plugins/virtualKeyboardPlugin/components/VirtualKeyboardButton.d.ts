import React, { CSSProperties, ReactNode } from "react";
import { VirtualKeyboardHandler } from "../VirtualKeyboardHandler";
export interface VirtualKeyboardButtonProps {
    keyCode: string;
    /** Additional key codes that should also light up this button (e.g. WASD aliases for arrow buttons). */
    aliasKeyCodes?: string[];
    handler: VirtualKeyboardHandler;
    children?: ReactNode;
    className?: string;
    style?: CSSProperties;
}
/**
 * Engine-provided virtual keyboard button.
 *
 * Uses Pointer Events so it responds immediately on both mouse and touch
 * (no 300 ms synthetic mouse delay). Dispatches real DOM KeyboardEvents via
 * the handler so every plugin/module (DoubleTapRun, DirectionControl, etc.)
 * picks them up the same way it picks up physical key presses.
 *
 * Style via `className` or `style` — the engine applies no visual opinions.
 * A `data-active` attribute is set while the key is held so CSS selectors
 * ([data-active]) can drive hover/press styling.
 */
export declare const VirtualKeyboardButton: ({ keyCode, aliasKeyCodes, handler, children, className, style }: VirtualKeyboardButtonProps) => React.JSX.Element;
