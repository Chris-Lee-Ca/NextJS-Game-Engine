import PluginHandler from "../PluginHandler";
export interface VirtualKeyboardHandlerConfig {
    onKeyDown?: (key: string) => void;
    onKeyUp?: (key: string) => void;
}
export declare class VirtualKeyboardHandler implements PluginHandler {
    pluginId: string;
    private config;
    constructor(config?: VirtualKeyboardHandlerConfig);
    init(): void;
    deinit(): void;
    update(_deltaTime: number): void;
    dispatchKeyDown(key: string): void;
    dispatchKeyUp(key: string): void;
}
