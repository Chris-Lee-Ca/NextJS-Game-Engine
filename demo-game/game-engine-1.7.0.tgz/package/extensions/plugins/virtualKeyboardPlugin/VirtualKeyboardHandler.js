import { VIRTUAL_KEYBOARD_PLUGIN_ID } from "./constants";
export class VirtualKeyboardHandler {
    constructor(config = {}) {
        this.pluginId = VIRTUAL_KEYBOARD_PLUGIN_ID;
        this.config = config;
    }
    init() { }
    deinit() { }
    update(_deltaTime) { }
    dispatchKeyDown(key) {
        var _a, _b;
        if (typeof window === "undefined")
            return;
        window.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true }));
        (_b = (_a = this.config).onKeyDown) === null || _b === void 0 ? void 0 : _b.call(_a, key);
    }
    dispatchKeyUp(key) {
        var _a, _b;
        if (typeof window === "undefined")
            return;
        window.dispatchEvent(new KeyboardEvent("keyup", { key, bubbles: true }));
        (_b = (_a = this.config).onKeyUp) === null || _b === void 0 ? void 0 : _b.call(_a, key);
    }
}
