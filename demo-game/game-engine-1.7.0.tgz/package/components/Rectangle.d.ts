import { Vector2 } from "../types/general";
declare class Rectangle {
    x: number;
    y: number;
    width: number;
    height: number;
    constructor(x: number, y: number, width: number, height: number);
    clone(): Rectangle;
    getCenter(): Vector2;
    setCenter(center: Vector2): Rectangle;
    setPosition(x: number, y: number): Rectangle;
    contains(rect: Rectangle): boolean;
    overlaps(rect: Rectangle): boolean;
}
export default Rectangle;
