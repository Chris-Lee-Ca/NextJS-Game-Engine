export class GameObjectFactory {
}
