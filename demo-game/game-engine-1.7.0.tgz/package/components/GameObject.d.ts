import { ReactNode } from "react";
import { Coordinate, Placement, Vector2 } from "../types/general";
import Rectangle from "./Rectangle";
declare abstract class GameObject {
    id: string;
    coord: Coordinate;
    position: Vector2;
    bound: Rectangle | undefined;
    triggerBound?: Rectangle;
    constructor(placement: Placement);
    abstract update(deltaTime: number): void;
    abstract render(): ReactNode;
    onTriggerEnter(_other: GameObject): void;
    onTriggerExit(_other: GameObject): void;
    checkCollision(bound: Rectangle): GameObject[];
    abstract performCollisionLogic(object: GameObject): void;
    toString(): string;
}
export default GameObject;
