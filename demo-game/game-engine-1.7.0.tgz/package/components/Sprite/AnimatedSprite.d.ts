import { Animations, Offset, SpriteSheetInfo } from "../../types/general";
type AnimatedSpriteProps = {
    spriteSheetInfo: SpriteSheetInfo;
    imageOffset?: Offset;
    scaleFactor: number;
    animations: Animations;
    currentAnimation: string;
    frameDelay?: number;
};
declare const AnimatedSprite: (props: AnimatedSpriteProps) => import("react").JSX.Element;
export default AnimatedSprite;
