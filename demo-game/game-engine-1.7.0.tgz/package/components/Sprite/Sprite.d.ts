import { Offset, SpriteSheetInfo } from "../../types/general";
type SpriteProps = {
    spriteSheetInfo: SpriteSheetInfo;
    imageOffset?: Offset;
    scaleFactor: number;
};
declare const Sprite: (props: SpriteProps) => import("react").JSX.Element;
export default Sprite;
