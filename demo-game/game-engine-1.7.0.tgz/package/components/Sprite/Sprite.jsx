"use client";
import { useEffect, useRef } from "react";
import SpriteHelper from "../../helper/SpriteHelper";
import GridHelper from "../../helper/GridHelper";
const Sprite = (props) => {
    var _a;
    const { spriteSheetInfo, scaleFactor } = props;
    const imageOffset = (_a = props.imageOffset) !== null && _a !== void 0 ? _a : { x: 0, y: 0 };
    const canvasRef = useRef(null);
    const imageRef = useRef(typeof window !== "undefined" ? new Image() : null);
    const frame = SpriteHelper.spritePositionToImagePosition(0, 0, spriteSheetInfo, imageOffset);
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas)
            return;
        const context = canvas.getContext("2d");
        if (!context)
            return;
        const image = imageRef.current;
        if (image) {
            image.src = spriteSheetInfo.SRC;
            image.crossOrigin = "anonymous";
        }
        context.clearRect(0, 0, canvas.width, canvas.height);
        image.onload = () => {
            canvas.width = GridHelper.getGridSizeInPixel();
            canvas.height = GridHelper.getGridSizeInPixel();
            context.drawImage(image, frame.x, frame.y, spriteSheetInfo.WIDTH, spriteSheetInfo.HEIGHT, 0, 0, spriteSheetInfo.WIDTH * scaleFactor, // Scaled width
            spriteSheetInfo.HEIGHT * scaleFactor // Scaled height
            );
        };
    }, []);
    return <canvas ref={canvasRef}></canvas>;
};
export default Sprite;
