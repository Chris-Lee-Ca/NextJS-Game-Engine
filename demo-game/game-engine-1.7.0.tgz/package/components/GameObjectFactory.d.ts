import { AppStore } from "../redux/store";
import { Placement } from "../types/general";
import GameObject from "./GameObject";
export type CreateObjectParams<StoreType = AppStore> = {
    placement: Placement;
    reduxStore?: StoreType;
};
export declare abstract class GameObjectFactory<StoreType = AppStore> {
    abstract createObject(params: CreateObjectParams<StoreType>): GameObject;
}
