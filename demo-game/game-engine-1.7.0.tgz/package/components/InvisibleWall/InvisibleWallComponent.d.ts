declare const InvisibleWallComponent: () => import("react").JSX.Element;
export default InvisibleWallComponent;
