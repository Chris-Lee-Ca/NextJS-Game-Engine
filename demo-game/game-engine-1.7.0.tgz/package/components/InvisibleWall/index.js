import GameObject from "../GameObject";
import Rectangle from "../Rectangle";
import GridHelper from "../../helper/GridHelper";
import InvisibleWallComponent from "./InvisibleWallComponent";
import React from "react";
class InvisibleWall extends GameObject {
    constructor(params) {
        super(params.placement);
        const gridSize = GridHelper.getGridSizeInPixel();
        this.bound = new Rectangle(this.position.x, this.position.y, gridSize, gridSize);
    }
    update(_deltaTime) { }
    render() {
        return React.createElement(InvisibleWallComponent);
    }
    performCollisionLogic(_object) { }
}
export default InvisibleWall;
