import { ReactNode } from "react";
import GameObject from "../GameObject";
import { CreateObjectParams } from "../GameObjectFactory";
declare class InvisibleWall extends GameObject {
    constructor(params: CreateObjectParams);
    update(_deltaTime: number): void;
    render(): ReactNode;
    performCollisionLogic(_object: GameObject): void;
}
export default InvisibleWall;
