class Rectangle {
    constructor(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    clone() {
        return new Rectangle(this.x, this.y, this.width, this.height);
    }
    getCenter() {
        return {
            x: (this.x + this.x + this.width) / 2,
            y: (this.y + this.y + this.height) / 2,
        };
    }
    setCenter(center) {
        this.x = center.x - this.width / 2;
        this.y = center.y - this.height / 2;
        return this;
    }
    setPosition(x, y) {
        this.x = x;
        this.y = y;
        return this;
    }
    contains(rect) {
        return (this.x <= rect.x &&
            this.y <= rect.y &&
            this.x + this.width >= rect.x + rect.width &&
            this.y + this.height >= rect.y + rect.height);
    }
    overlaps(rect) {
        return !(this.x + this.width <= rect.x ||
            this.y + this.height <= rect.y ||
            this.x >= rect.x + rect.width ||
            this.y >= rect.y + rect.height);
    }
}
export default Rectangle;
