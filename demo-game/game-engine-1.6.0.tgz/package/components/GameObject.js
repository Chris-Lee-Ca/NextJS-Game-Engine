import Converter from "../helper/Converter";
import ObjectPool from "../core/ObjectPool";
class GameObject {
    constructor(placement) {
        this.id = placement.id;
        this.coord = placement.coord;
        this.position = Converter.coordToVector(this.coord);
    }
    checkCollision(bound) {
        const collisionList = [];
        for (let [object_id, object] of ObjectPool) {
            if (object_id === this.id)
                continue;
            if (typeof object.bound === "undefined")
                continue;
            if (bound.overlaps(object.bound)) {
                collisionList.push(object);
            }
        }
        return collisionList;
    }
    toString() {
        return `GameObject: type -- ${typeof this}, id -- ${this.id}`;
    }
}
export default GameObject;
