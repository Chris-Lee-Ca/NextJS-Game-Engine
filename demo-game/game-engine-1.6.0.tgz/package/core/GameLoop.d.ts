import PluginHandler from "../extensions/plugins/PluginHandler";
import ModuleHandler from "../extensions/modules/ModuleHandler";
import { AppStore } from "../redux/store";
interface GameLoopConfig {
    targetFPS: number;
    reduxStore: AppStore;
    plugins: PluginHandler[];
    modules: ModuleHandler[];
}
declare class GameLoop {
    static instance: GameLoop;
    store: AppStore;
    lastFrameTime: number;
    targetFPS: number;
    plugins: {
        [key: string]: PluginHandler;
    };
    modules: {
        [key: string]: ModuleHandler;
    };
    private constructor();
    static getInstance(gameLoopConfig: GameLoopConfig): GameLoop;
    start(): void;
    loop(currentTime: number): void;
    private update;
    stop(): void;
}
export default GameLoop;
