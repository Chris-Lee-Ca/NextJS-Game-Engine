import { updateTime } from "../redux/features/coreSlice";
import ObjectPool from "./ObjectPool";
class GameLoop {
    constructor({ targetFPS, reduxStore, plugins, modules }) {
        this.lastFrameTime = 0;
        this.targetFPS = targetFPS;
        this.store = reduxStore;
        this.plugins = plugins.reduce((acc, plugin) => {
            acc[plugin.pluginId] = plugin;
            return acc;
        }, {});
        this.modules = modules.reduce((acc, module) => {
            // Validate if all modules' related plugins are installed
            if (!(module.pluginId in this.plugins)) {
                throw new Error(`Plugin ${module.pluginId} is missing, which is a prerequisite of module ${module.moduleId}`);
            }
            acc[module.moduleId] = module;
            return acc;
        }, {});
        // init plugins
        Object.entries(this.plugins).forEach(([_key, pluginHandler]) => {
            pluginHandler.init();
        });
        // init modules
        Object.entries(this.modules).forEach(([_key, moduleHandler]) => {
            moduleHandler.init();
        });
    }
    static getInstance(gameLoopConfig) {
        if (!this.instance) {
            this.instance = new GameLoop(gameLoopConfig);
        }
        return this.instance;
    }
    start() {
        // Re-init plugins/modules in case a previous stop() removed their listeners.
        // addEventListener deduplicates same-reference listeners, so calling init()
        // here when already initialized (first start) is safe.
        Object.values(this.plugins).forEach((p) => p.init());
        Object.values(this.modules).forEach((m) => m.init());
        this.loop(0);
    }
    loop(currentTime) {
        requestAnimationFrame(this.loop.bind(this)); // Continue the loop
        const deltaTime = currentTime - this.lastFrameTime;
        const frameDuration = 1000 / this.targetFPS;
        if (deltaTime >= frameDuration) {
            this.lastFrameTime = currentTime;
            // Perform Game Logic Here
            this.update(deltaTime);
        }
    }
    update(deltaTime) {
        this.store.dispatch(updateTime());
        // update plugins
        Object.entries(this.plugins).forEach(([_key, pluginHandler]) => {
            pluginHandler.update(deltaTime);
        });
        // update modules
        Object.entries(this.modules).forEach(([_key, moduleHandler]) => {
            moduleHandler.update(deltaTime);
        });
        // update game object
        const state = this.store.getState();
        const objectIdPool = state.core.objectIdPool;
        objectIdPool.forEach((objectId) => {
            const object = ObjectPool.get(objectId);
            object === null || object === void 0 ? void 0 : object.update(deltaTime);
        });
    }
    stop() {
        // deinit modules
        Object.entries(this.modules).forEach(([_key, moduleHandler]) => {
            moduleHandler.deinit();
        });
        // deinit plugins
        Object.entries(this.plugins).forEach(([_key, pluginHandler]) => {
            pluginHandler.deinit();
        });
    }
}
export default GameLoop;
