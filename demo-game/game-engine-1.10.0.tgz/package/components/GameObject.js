import Converter from "../helper/Converter";
import ObjectPool from "../core/ObjectPool";
class GameObject {
    constructor(placement) {
        this.id = placement.id;
        this.coord = placement.coord;
        this.position = Converter.coordToVector(this.coord);
    }
    onTriggerEnter(_other) { }
    onTriggerExit(_other) { }
    checkCollision(bound) {
        const collisionList = [];
        for (let [object_id, object] of ObjectPool) {
            if (object_id === this.id)
                continue;
            if (typeof object.bound === "undefined")
                continue;
            if (bound.overlaps(object.bound)) {
                collisionList.push(object);
            }
        }
        return collisionList;
    }
    performCollisionLogic(_object) { }
    moveAndCollide(newPosition, newBound, onCommit) {
        const collisions = this.checkCollision(newBound);
        for (const object of collisions) {
            object.performCollisionLogic(this);
        }
        const blocked = collisions.length > 0;
        if (!blocked) {
            this.position = newPosition;
            this.bound = newBound;
            onCommit === null || onCommit === void 0 ? void 0 : onCommit(); // called after position/bound are set, for any extra derived state
        }
        return { blocked, collisions };
    }
    toString() {
        return `GameObject: type -- ${typeof this}, id -- ${this.id}`;
    }
}
export default GameObject;
