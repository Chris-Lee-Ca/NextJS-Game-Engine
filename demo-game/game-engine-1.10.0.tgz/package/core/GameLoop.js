import { updateTime } from "../redux/features/coreSlice";
import ObjectPool from "./ObjectPool";
class GameLoop {
    constructor({ targetFPS, reduxStore, plugins, modules }) {
        this.triggerOverlapState = new Map();
        this.lastFrameTime = 0;
        this.nextFrameTime = 0;
        this.targetFPS = targetFPS;
        this.store = reduxStore;
        this.plugins = plugins.reduce((acc, plugin) => {
            acc[plugin.pluginId] = plugin;
            return acc;
        }, {});
        this.modules = modules.reduce((acc, module) => {
            // Validate if all modules' related plugins are installed
            if (!(module.pluginId in this.plugins)) {
                throw new Error(`Plugin ${module.pluginId} is missing, which is a prerequisite of module ${module.moduleId}`);
            }
            acc[module.moduleId] = module;
            return acc;
        }, {});
        // init plugins
        Object.entries(this.plugins).forEach(([_key, pluginHandler]) => {
            pluginHandler.init();
        });
        // init modules
        Object.entries(this.modules).forEach(([_key, moduleHandler]) => {
            moduleHandler.init();
        });
    }
    static getInstance(gameLoopConfig) {
        if (!this.instance) {
            this.instance = new GameLoop(gameLoopConfig);
        }
        return this.instance;
    }
    start() {
        // Re-init plugins/modules in case a previous stop() removed their listeners.
        // addEventListener deduplicates same-reference listeners, so calling init()
        // here when already initialized (first start) is safe.
        Object.values(this.plugins).forEach((p) => p.init());
        Object.values(this.modules).forEach((m) => m.init());
        this.loop(0);
    }
    loop(currentTime) {
        requestAnimationFrame(this.loop.bind(this));
        // Allow 1ms early to absorb rAF timestamp jitter at the frame boundary.
        const FRAME_SLACK_MS = 1;
        if (currentTime + FRAME_SLACK_MS < this.nextFrameTime)
            return;
        const deltaTime = currentTime - this.lastFrameTime;
        this.lastFrameTime = currentTime;
        this.nextFrameTime = currentTime + 1000 / this.targetFPS;
        this.update(deltaTime);
    }
    update(deltaTime) {
        this.store.dispatch(updateTime());
        // update plugins
        Object.entries(this.plugins).forEach(([_key, pluginHandler]) => {
            pluginHandler.update(deltaTime);
        });
        // update modules
        Object.entries(this.modules).forEach(([_key, moduleHandler]) => {
            moduleHandler.update(deltaTime);
        });
        // update game object
        const state = this.store.getState();
        const objectIdPool = state.core.objectIdPool;
        objectIdPool.forEach((objectId) => {
            const object = ObjectPool.get(objectId);
            object === null || object === void 0 ? void 0 : object.update(deltaTime);
        });
        // update trigger overlap state
        this.processTriggers();
    }
    // Runs every frame after all object updates.
    // For every object that defines a triggerBound, checks which other objects'
    // solid bounds overlap it, then fires onTriggerEnter / onTriggerExit for
    // objects that newly entered or left since the previous frame.
    // Unlike performCollisionLogic (which blocks movement), triggers are passive —
    // they never affect physics, only notify the owner.
    processTriggers() {
        var _a;
        // Pre-filter once per frame: avoids O(n²) by not scanning all ObjectPool entries in the inner loop.
        const triggerObjects = [];
        const boundedObjects = [];
        for (const [id, obj] of ObjectPool) {
            if (obj.triggerBound)
                triggerObjects.push([id, obj]);
            if (obj.bound)
                boundedObjects.push([id, obj]);
        }
        for (const [triggerId, triggerObject] of triggerObjects) {
            const previousOverlaps = (_a = this.triggerOverlapState.get(triggerId)) !== null && _a !== void 0 ? _a : new Set();
            const currentOverlaps = new Set();
            // Build the set of objects currently inside this trigger zone.
            for (const [otherId, otherObject] of boundedObjects) {
                if (otherId === triggerId)
                    continue;
                if (triggerObject.triggerBound.overlaps(otherObject.bound)) {
                    currentOverlaps.add(otherId);
                }
            }
            // Fire enter for objects that weren't inside last frame.
            for (const id of currentOverlaps) {
                if (!previousOverlaps.has(id)) {
                    triggerObject.onTriggerEnter(ObjectPool.get(id));
                }
            }
            // Fire exit for objects that were inside last frame but no longer are.
            for (const id of previousOverlaps) {
                if (!currentOverlaps.has(id)) {
                    triggerObject.onTriggerExit(ObjectPool.get(id));
                }
            }
            this.triggerOverlapState.set(triggerId, currentOverlaps);
        }
    }
    stop() {
        // deinit modules
        Object.entries(this.modules).forEach(([_key, moduleHandler]) => {
            moduleHandler.deinit();
        });
        // deinit plugins
        Object.entries(this.plugins).forEach(([_key, pluginHandler]) => {
            pluginHandler.deinit();
        });
    }
}
export default GameLoop;
