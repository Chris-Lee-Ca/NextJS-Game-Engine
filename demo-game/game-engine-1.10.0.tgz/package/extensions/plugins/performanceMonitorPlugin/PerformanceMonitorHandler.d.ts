import PluginHandler from "../PluginHandler";
import { AppDispatch } from "./performanceMonitorSlice";
export interface PerformanceMonitorHandlerConfig {
    dispatch: AppDispatch;
    toggleKey?: string;
}
export declare class PerformanceMonitorHandler implements PluginHandler {
    pluginId: string;
    private dispatch;
    private toggleKey;
    private deltaBuffer;
    private lastDispatchTime;
    constructor({ dispatch, toggleKey }: PerformanceMonitorHandlerConfig);
    init(): void;
    deinit(): void;
    update(deltaTime: number): void;
    private handleKey;
}
