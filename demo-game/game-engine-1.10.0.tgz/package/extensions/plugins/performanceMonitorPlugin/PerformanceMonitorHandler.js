import { PERFORMANCE_MONITOR_PLUGIN_ID, DEFAULT_TOGGLE_KEY } from "./constants";
import { setStats, toggleVisible } from "./performanceMonitorSlice";
const BUFFER_SIZE = 60;
const DISPATCH_INTERVAL_MS = 250;
export class PerformanceMonitorHandler {
    constructor({ dispatch, toggleKey = DEFAULT_TOGGLE_KEY }) {
        this.pluginId = PERFORMANCE_MONITOR_PLUGIN_ID;
        this.deltaBuffer = [];
        this.lastDispatchTime = 0;
        this.handleKey = (e) => {
            if (e.repeat)
                return;
            if (e.key === this.toggleKey) {
                this.dispatch(toggleVisible());
            }
        };
        this.dispatch = dispatch;
        this.toggleKey = toggleKey;
    }
    init() {
        if (typeof window !== "undefined") {
            window.addEventListener("keydown", this.handleKey);
        }
    }
    deinit() {
        if (typeof window !== "undefined") {
            window.removeEventListener("keydown", this.handleKey);
        }
    }
    update(deltaTime) {
        if (deltaTime <= 0)
            return;
        this.deltaBuffer.push(deltaTime);
        if (this.deltaBuffer.length > BUFFER_SIZE) {
            this.deltaBuffer.shift();
        }
        const now = performance.now();
        if (now - this.lastDispatchTime < DISPATCH_INTERVAL_MS)
            return;
        this.lastDispatchTime = now;
        const avg = this.deltaBuffer.reduce((sum, d) => sum + d, 0) / this.deltaBuffer.length;
        this.dispatch(setStats({ fps: 1000 / avg }));
    }
}
