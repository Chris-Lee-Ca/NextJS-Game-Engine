import type { PayloadAction } from "@reduxjs/toolkit";
export interface PerformanceMonitorState {
    visible: boolean;
    fps: number;
}
export declare const performanceMonitorSlice: import("@reduxjs/toolkit").Slice<PerformanceMonitorState, {
    toggleVisible: (state: import("immer").WritableDraft<PerformanceMonitorState>) => void;
    setStats: (state: import("immer").WritableDraft<PerformanceMonitorState>, action: PayloadAction<{
        fps: number;
    }>) => void;
}, "performanceMonitor", "performanceMonitor", import("@reduxjs/toolkit").SliceSelectors<PerformanceMonitorState>>;
export declare const toggleVisible: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"performanceMonitor/toggleVisible">, setStats: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    fps: number;
}, "performanceMonitor/setStats">;
export declare const performanceMonitorReducer: import("redux").Reducer<PerformanceMonitorState>;
declare const makeStore: () => import("@reduxjs/toolkit").EnhancedStore<{
    "performance-monitor": PerformanceMonitorState;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<{
        "performance-monitor": PerformanceMonitorState;
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
export type AppStore = ReturnType<typeof makeStore>;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];
export {};
