import { CSSProperties } from "react";
export interface PerformanceOverlayProps {
    style?: CSSProperties;
}
export declare const PerformanceOverlay: ({ style }: PerformanceOverlayProps) => import("react").JSX.Element | null;
