import { configureStore, createSlice } from "@reduxjs/toolkit";
import { PERFORMANCE_MONITOR_PLUGIN_ID } from "./constants";
const initialState = {
    visible: true,
    fps: 0,
};
export const performanceMonitorSlice = createSlice({
    name: "performanceMonitor",
    initialState,
    reducers: {
        toggleVisible: (state) => {
            state.visible = !state.visible;
        },
        setStats: (state, action) => {
            state.fps = action.payload.fps;
        },
    },
});
export const { toggleVisible, setStats } = performanceMonitorSlice.actions;
export const performanceMonitorReducer = performanceMonitorSlice.reducer;
const makeStore = () => {
    return configureStore({
        reducer: {
            [PERFORMANCE_MONITOR_PLUGIN_ID]: performanceMonitorReducer,
        },
    });
};
