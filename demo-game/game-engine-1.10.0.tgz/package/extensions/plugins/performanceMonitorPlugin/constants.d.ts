export declare const PERFORMANCE_MONITOR_PLUGIN_ID = "performance-monitor";
export declare const DEFAULT_TOGGLE_KEY = "`";
